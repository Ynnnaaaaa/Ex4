Our Excercise in Intprog
