<?php

//if it wants to put another file just clear the slash
//file_put_contents('text.txt', "Hi this is Group 8 excercise 3. ");

//showing the text inside the file location you select
echo file_get_contents('text.txt');